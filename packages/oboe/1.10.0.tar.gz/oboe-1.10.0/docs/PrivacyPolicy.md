[Home](README.md)

# Oboe Privacy Policy

Oboe is a library that simply passes audio between the application and the native Android APIs.

Oboe does not collect any user data or information.

Oboe does not create Cookies.

Oboe is considered "kid safe".
